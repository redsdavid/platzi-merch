import React from 'react';
import '../styles/components/app.css';

const App = () => <h1>¡Holis mundo!</h1>;

export default App;
